import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PopupdailogComponent } from './popupdailog.component';

describe('PopupdailogComponent', () => {
  let component: PopupdailogComponent;
  let fixture: ComponentFixture<PopupdailogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PopupdailogComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PopupdailogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
