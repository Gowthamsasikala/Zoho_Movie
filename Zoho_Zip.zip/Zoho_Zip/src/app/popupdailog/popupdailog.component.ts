import { Component, OnInit, Inject } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'app-popupdailog',
  templateUrl: './popupdailog.component.html',
  styleUrls: ['./popupdailog.component.css']
})
export class PopupdailogComponent implements OnInit {

  public selectedData:any;
  tvSelectedData:any;
  Movietype = false;
  constructor(@Inject(MAT_DIALOG_DATA) public data: any) {
  
  }

  ngOnInit(): void {
    console.log(this.data)
    if(this.data[1]== 'movie'){
      this.Movietype = true;
      this.selectedData = this.data[0];      
    }else{
      this.Movietype = false;
      this.tvSelectedData = this.data[0];
    }
  }

}



