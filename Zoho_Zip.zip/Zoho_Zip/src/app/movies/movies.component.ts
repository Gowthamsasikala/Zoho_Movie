import { Component, OnInit } from '@angular/core';
import { GetMoviesService } from '../Services/get-movies.service';

@Component({
  selector: 'app-movies',
  templateUrl: './movies.component.html',
  styleUrls: ['./movies.component.css']
})
export class MoviesComponent implements OnInit {

  public toPhoneNumber:any = '+91';
  public body:any;
  emailId:any;
  username:any;
  constructor(private service:GetMoviesService) { }

  ngOnInit(): void {
  

  }

  sendMsg() {
    const bodys = 'Hi '+this.username+", "+this.body;
    this.service.sendMessage(bodys,this.toPhoneNumber).subscribe(data => {
      console.log(data);
    })
  }

}
