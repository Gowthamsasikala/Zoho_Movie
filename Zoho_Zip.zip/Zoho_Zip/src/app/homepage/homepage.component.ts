import { Component, OnInit } from '@angular/core';
import { GetMoviesService } from '../Services/get-movies.service';
import { MatDialog } from '@angular/material/dialog';
import { PopupdailogComponent } from '../popupdailog/popupdailog.component';

@Component({
  selector: 'app-homepage',
  templateUrl: './homepage.component.html',
  styleUrls: ['./homepage.component.css']
})
export class HomepageComponent implements OnInit {

  toggleView: any;
  toggleCardView: any;
  public searchData: any;
  public movielistData: any;
  public displayError = false;
  public toggleData: any;
  displayTvData = false;
  public tvListData: any;
  public tableView: any = true;
  cartCount = 0;
  len :any;
  constructor(private service: GetMoviesService, public dialog: MatDialog) { }

  ngOnInit(): void {
    let cartVal = JSON.parse(JSON.stringify(sessionStorage.getItem('cart')));
    console.log(cartVal);
    if (cartVal) {
      this.len = JSON.parse(cartVal);
      this.cartCount = this.len.length;
      console.log(this.cartCount);
    }
  }

  toggle($event: any) {
    console.log($event.target.id);
    this.toggleData = $event.target.id;
    if (this.toggleData == 'tv') {
      this.displayTvData = true;
    } else {
      this.displayTvData = false;
    }
  }

  toggleCard($event: any) {
    console.log($event.target.id);
  }


  search() {
    this.service.getMovieList(this.searchData).subscribe(data => {
      this.movielistData = data;
      console.log(this.movielistData);
      if (this.movielistData.Search == undefined) {
        this.displayError = true;
      } else {
        this.displayError = false;
      }
    });

    this.service.getTvList(this.searchData).subscribe(data => {
      this.tvListData = data;
      console.log(this.tvListData, "tv");

    })
  }

  popUpData(datavalue: any, type: any) {
    console.log(datavalue);
    const arr = [];
    arr.push(datavalue);
    arr.push(type);
    this.dialog.open(PopupdailogComponent, {
      data: arr
    });
  }

  tabs($event: any) {
    console.log($event.target.id);
    this.toggleView = $event.target.id;

    if (this.toggleView == 'Table') {
      this.tableView = true;
    } else {
      this.tableView = false;
    }
  }

  tabsCard($event: any) {
    console.log($event.target.id);
  }


  addCart(data: any) {

    let cartArr = [];
    let cartVal = JSON.parse(JSON.stringify(sessionStorage.getItem('cart')));
    console.log(cartVal);
    if (cartVal) {
      this.len = JSON.parse(cartVal);
      this.cartCount = this.len.length;
      console.log(this.cartCount);
      
      for(let data1 of JSON.parse(cartVal)){
        cartArr.push(data1);
      }
      cartArr.push(data);
    } else { 
      cartArr.push(data) 
    }
    this.cartCount = cartArr.length;

    sessionStorage.setItem('cart', JSON.stringify(cartArr));
  }
}
