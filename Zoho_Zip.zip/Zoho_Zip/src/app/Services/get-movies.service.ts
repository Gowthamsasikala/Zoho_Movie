import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class GetMoviesService {

  public URL: any;
  constructor(private http: HttpClient) { }


  getMovieList(data: any) {
    this.URL = "https://www.omdbapi.com/?";
    this.URL = this.URL + "s=" + data + "&apikey=32e78858";
    console.log(this.URL);
    return this.http.get(this.URL);
  }

  getTvList(data: any) {
    const url = "https://api.tvmaze.com/search/shows?q=" + data;
    console.log(url);
    return this.http.get(url);
  }

  sendMessage(data:any,to:any) {
    const url = "https://api.twilio.com/2010-04-01/Accounts/AC230ae781243f5cf2a495e5be000fdce9/Messages.json";

    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type' : 'application/x-www-form-urlencoded',
      'Authorization': 'Basic ' + btoa('AC230ae781243f5cf2a495e5be000fdce9:22d084d34edb63bf419538c24ea94f2e')
    })
    }

    let body = new URLSearchParams();
    body.set('From', '+12815423088')
    body.set('To', to)
    body.set('Body', data)

    return this.http.post(url,body,httpOptions)
  }

}
